package edu.neumont.csc110.drills;

public enum Flinstones {
	Fred,
	Wilma,
	Pebbles
}
